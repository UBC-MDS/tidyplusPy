from distutils.core import setup

setup(
    name='tidyplusPy',
    author='Akshi Chaudhary, Yue (Tina) Qian, Xinbin Huang',
    version='0.1dev',
    packages=['tidyplusPy',],
    license='MIT',
    long_description=open('README.txt').read(),
)
